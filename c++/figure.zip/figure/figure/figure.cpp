﻿#include "figure.h"
#include <iostream>
#include <string>
#define _USE_MATH_DEFINES
#include <cmath>
#include <vector>
using namespace std;

int main()
{
	setlocale(LC_ALL, "Russian");
	vector<figure*> figures;
	Circle circle1(2.0);
	Circle circle2(3.0);
	Rectangle rec(1.0, 4.0);

	figures.push_back(&circle1);
	figures.push_back(&circle2);
	figures.push_back(&rec);

	double sq = 0.0;
	for (int i = 0; i < figures.size(); i++)
	{
		sq += figures[i]->calc_area();
		cout << "sq" << i << " = " << figures[i]->calc_area() << endl;
	}
	cout << "total = " << sq << endl;
	circle1.name();
	return 0;
}