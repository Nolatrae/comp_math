#ifndef _figure_
#define _figure_
#include <iostream>
#include <string>
#define _USE_MATH_DEFINES
#include <cmath>
using namespace std;

struct point {
	double x, y;
	point() : x(0), y(0) {};
	point(double ax, double ay) : x(ax), y(ay) {};
};

class figure
{
public:
	virtual double calc_area() = 0;
	virtual double calc_perimetr() = 0;
	virtual void name() = 0;
};

class Circle : public figure
{
public:
	double R;
	Circle() { R = 0.0; }
	Circle(double _R) { R = _R; };
	double calc_area();
	double calc_perimetr();
	void name();
};

class Ellipse : public figure
{
public:
	double a, b;
	Ellipse() { a = b = 0.0; };
	Ellipse(double _a, double _b) { a = _a, b = _b; };
	double calc_area();
	double calc_perimetr();
	void name();
};

class Rectangle : public figure
{
public:
	double a, b;
	Rectangle() { a = b = 0.0; };
	Rectangle(double _a, double _b) { a = _a, b = _b; };
	Rectangle(const point& a, const point& b, const point& c, point& d);
	//Rectangle(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4);
	double calc_area();
	double calc_perimetr();
	void name();
};
#endif // 
