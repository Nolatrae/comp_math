#include "figure.h"
#include <iostream>
#include <string>
#include<math.h>
#define M_PI 3.14159265358979323846
#define _USE_MATH_DEFINES


double Circle::calc_area()
{
	return R * R * M_PI;
}

double Circle::calc_perimetr()
{
	return 2 * R * M_PI;
}

void Circle::name()
{
	cout << "����" << endl;
}


double Ellipse::calc_area()
{
	return a * b * M_PI;
}

double Ellipse::calc_perimetr()
{
	return (4 * (M_PI * a * b) + ((a - b) * (a - b))) / (a + b);
}

void Ellipse::name()
{
	cout << "�����" << endl;
}


double Rectangle::calc_area()
{
	return a * b;
}

double Rectangle::calc_perimetr()
{
	return 2 * (a+b);
}

void Rectangle::name()
{
	cout << "�������������" << endl;
}